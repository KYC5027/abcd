package com.lgy.pet_platform_2.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lgy.pet_platform_2.dao.UserDAO;
import com.lgy.pet_platform_2.dto.UserDTO;

@Service("UserService")
public class UserServiceImpl implements UserService{

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public ArrayList<UserDTO> loginYn(HashMap<String, String> param) {
		UserDAO dao=sqlSession.getMapper(UserDAO.class);
		ArrayList<UserDTO> list = dao.loginYn(param);
		
		return list;
	}

	@Override
	public void write(HashMap<String, String> param) {
		UserDAO dao=sqlSession.getMapper(UserDAO.class);
		dao.write(param);
	}

//	@Override
//	public HashMap<String, String> getUserInfo(String user_id) {
//		UserDAO dao = sqlSession.getMapper(UserDAO.class);
//		return dao.getUserInfo(user_id);
//	}
	
 @Override
    public UserDTO getUserInfo(String user_id) {
        UserDAO dao = sqlSession.getMapper(UserDAO.class);
        return dao.getUserInfo(user_id);
    }

    @Override
    public void updateUserInfo(UserDTO user) {
        UserDAO dao = sqlSession.getMapper(UserDAO.class);
        dao.updateUserInfo(user);
    }

	@Override
	public int idCheck(String user_id) {
	    UserDAO dao = sqlSession.getMapper(UserDAO.class);
	    return dao.idCheck(user_id);
	}

	@Override
	public int nickCheck(String nick) {
		UserDAO dao = sqlSession.getMapper(UserDAO.class);
		return dao.nickCheck(nick);
	}
}

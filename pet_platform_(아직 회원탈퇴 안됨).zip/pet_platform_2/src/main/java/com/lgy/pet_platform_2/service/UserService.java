package com.lgy.pet_platform_2.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.lgy.pet_platform_2.dto.UserDTO;


public interface UserService {
	public ArrayList<UserDTO> loginYn(HashMap<String, String> param);
	public void write(HashMap<String, String> param);
//	HashMap<String, String> getUserInfo(String user_id);
    UserDTO getUserInfo(String user_id);
    void updateUserInfo(UserDTO user);
    public int idCheck(String user_id);
    public int nickCheck(String nick);
}
